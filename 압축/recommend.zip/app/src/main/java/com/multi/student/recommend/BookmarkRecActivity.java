package com.multi.student.recommend;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class BookmarkRecActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<Myitem> plist; //data
    Myadapter adapter;//adapter 관리자
    TextView recAddress;
    String[] arr = new String[50];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmark_rec);
        listView = (ListView)findViewById(R.id.listView);
        recAddress =(TextView)findViewById(R.id.recAddress);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(arr[position+1]));
                startActivity(i);
            }
        });

        plist = new ArrayList<>();
        //1.data 준비
        Myitem p1 = new Myitem(R.mipmap.ic_launcher,"김치","http://m.naver.com/","2800");
        Myitem p2 = new Myitem(R.mipmap.ic_launcher_round,"감자","주소asdfa","3000");
        Myitem p3 = new Myitem(R.mipmap.ic_launcher_round,"고구마","www.nd","333");

        plist.add(p1);
        plist.add(p2);
        plist.add(p3);
        arr[1]=p1.getAddress();
        arr[2]=p2.getAddress();
        arr[3]=p3.getAddress();

        //2.adapter
        adapter = new Myadapter(
                this, //Activity
                R.layout.activity_mylist, //ListView 안에 들어가는 item을 위한 xml
                plist //data가 들어 있는 ArrayList
        );

        //3.Listview에 adapter 지정
        listView.setAdapter(adapter);


    }
}
